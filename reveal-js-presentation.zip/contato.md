# Contato


## Redes sociais

- <span class="mdi mdi-github"></span> github.com/guionardo
- <span class="mdi mdi-twitter"></span> twitter.com/guionardo
- <span class="mdi mdi-linkedin"></span> linkedin.com/in/guionardo
- <span class="mdi mdi-post"></span> dev.to/guionardo
- <span class="mdi mdi-email"></span> guionardo@gmail.com


## Jobs na Ambev Tech

- <span class="mdi mdi-web"></span> ambevtech.com.br
- <span class="mdi mdi-cash"></span> ambevtech.gupy.io
- <span class="mdi mdi-email"></span> guionardo.furlan@ambevtech.com.br

Note: Usar o e-mail ambevtech para referenciar indicação no gupy