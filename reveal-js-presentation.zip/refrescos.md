# REFRESCOS

<img src="images/oh-god-why.svg" height="50%"/><br/>
<small>(Activision/Reprodução)</small>


## Refresco (1)

<table>
<tr><td width="30%"><img src="images/mri-0.png" /></td>
<td>Atualização do python para a versão 3.8.5</td></tr></table>


## Buraco (2)

<table>
<tr><td width="30%"><img src="images/mri-1.png" /></td>
<td>PIP não será liberado.<br/>
Todo o desenvolvimento deve ser feito usando a biblioteca padrão.</td>
</td></tr></table>

Note: Robôs do ERP criarão arquivos JSON que


## Buraco (3)

<table>
<tr><td width="30%"><img src="images/mri-2.png" /></td>
<td>Concorrência com outros serviços é inevitável.</td></tr></table>


## Refresco (4)

<table>
<tr><td width="30%"><img src="images/mri-0.png" /></td>
<td>Atualização do python resolveu o problema com o SSL.</td></tr></table>


## Refresco (5)

<table>
<tr><td width="30%"><img src="images/mri-0.png" /></td>
<td>Responsabilidade do house keeping foi delegada a outro serviço.</td></tr></table>


## Buraco (6)

<table>
<tr><td width="30%"><img src="images/mri-2.png" /></td>
<td>Volume de mensagens é inevitável.</td></tr></table>


## Refresco (7)

<table>
<tr><td width="30%"><img src="images/mri-1.png" /></td>
<td>Latência de rede pode ser contornada com o uso de pool de conexões HTTP e compactação dos payloads durante a transmissão para as APIs.</td></tr></table>