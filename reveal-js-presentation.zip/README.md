# Palestra Case Platform

https://guionardo.github.io/palestra-case-platform