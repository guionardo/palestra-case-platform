# Contexto


## ERP

<table>
<tr><td><img src="images/cobol.svg" /></td>
<td>Software desenvolvido internamente, com mais de 20 anos de idade e em processo de descomissionamento.<br/>
Responsável pela operação AmBev em nível nacional.</td></tr></table>

Note: This will only appear in the speaker notes window.


## Ambiente de execução

<span class="icon-aix"></span> Servidores AIX gerenciados e distribuidos por geografia.


## Tecnologias de desenvolvimento

* COBOL
* Shell script
* Perl
* C
* Python


## Problema Geral

Extração contínua de dados do ERP via eventos de estado para disponibilização ao novo ecossistema de microsserviços.
